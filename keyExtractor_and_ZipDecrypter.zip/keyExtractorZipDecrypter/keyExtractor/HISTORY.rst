=======
History
=======

0.3.1 (2018-11-17)
------------------

* Add support for Python 3.4, 3.5
* Add travis ci integration.
* Fix bug in local file header record.

0.2.0 (2018-11-17)
------------------

* Second release on PyPI.

0.1.0 (2018-11-07)
------------------

* First release on PyPI.
