=================
API Documentation
=================

This is the detailed documentation of ``AESZipFile``, which
holds all the functionality of ``pyzipper``.

.. currentmodule:: pyzipper.zipfile_aes

.. autosummary::
   :nosignatures:
   :toctree: api/

   AESZipFile
   AESZipInfo
