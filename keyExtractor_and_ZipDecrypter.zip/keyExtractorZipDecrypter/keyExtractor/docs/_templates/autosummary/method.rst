{{ name  | escape | underline }}

.. automethod:: {{ fullname }}
    :noindex:
