import pyzipper

def main():
	inFile = 'C:\\Users\\user1\\Desktop\\encryptedZipFile.zip' #Path and filename of encrypted Zip file
	outDir = 'C:\\Users\\user1\\Desktop\\\keyExtractor\\extractedFiles' #Path where decrypted files will be extracted
	userInput = input("Enter password for the ZIP file: ")
	pwd = bytes(userInput, 'utf-8')
	print("pwd: ", pwd)
	open('keys.txt', 'w').close() #Clears the contents of the text file containing keys
	with pyzipper.AESZipFile(inFile) as fileIn:
		fileIn.setpassword(pwd)
		list_files = fileIn.namelist()
		fileIn.extractall(outDir)
		
if __name__ == '__main__': main()
