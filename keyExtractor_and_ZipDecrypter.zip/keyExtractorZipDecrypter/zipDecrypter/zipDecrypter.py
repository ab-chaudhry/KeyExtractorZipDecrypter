import pyzipper

enckey = ''

def enterKey(key):
	key = input("Please enter the key for selected file in HexaDecimal form without any spaces: ")
	enckey = key
	print("enckey: ", enckey)
	return enckey

def main():
	inFile = 'C:\\Users\\user1\\Desktop\\encryptedZipFile.zip' #Path and filename of encrypted Zip file
	outDir = 'C:\\Users\\user1\\Desktop\\DecryptedFiles' #Path for folder where decrypted files will be extracted
	with pyzipper.AESZipFile(inFile) as fileIn:
		list_files = fileIn.namelist()
		print("Following files are in the Zip File: ", list_files)
		selection = input("Please choose an option: " +
				"\nEnter '1' to select first file." +
				"\nEnter '2' to select second file." +
				"\nEnter '3' to select third file." +
				"\nEnter '4' to stop program." +
				"\n: ")
		if selection == "1": #If '1' is selected,
			selectedFile = list_files[0]
			print("File selected: ", list_files[0])
			key = bytes(enterKey(enckey), 'utf-8')
			#print("Entered Key: ", key)
			fileIn.setpassword(key)
			fileIn.extract(selectedFile, outDir)
		elif selection == "2": #If '2' is selected,
			selectedFile = list_files[1]
			print("File selected: ", list_files[1])
			key = bytes(enterKey(enckey), 'utf-8')
			#print("Entered Key: ", key)
			fileIn.setpassword(key)
			fileIn.extract(selectedFile, outDir)
		elif selection == '3': #If '3' is selected,
			selectedFile = list_files[2]
			print("File selected: ", list_files[2])
			key = bytes(enterKey(enckey), 'utf-8')
			#print("Entered Key: ", key)
			fileIn.setpassword(key)
			fileIn.extract(selectedFile, outDir)
		elif selection == '4': #If '4' is selected,
			sys.exit #exit program
		else: #If wrong selection,
			print("Invalid input! Try again.") #print this statement and,
			main() #Re-run 'main' function
		print("Selected file decrypted and extracted in dir: ", outDir)

if __name__ == '__main__': main()
